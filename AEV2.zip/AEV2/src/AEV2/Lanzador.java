package AEV2;
//CLASE LANZADOR

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lanzador {

	//Variables globales para poder utilizarlas en cualquier parte del programa que obtionen el numero total de cores disponibles
	static int cores = Runtime.getRuntime().availableProcessors();
	static int maxCores=1;

	@SuppressWarnings("resource")
	//Lanzador de la clase procesosNeos que recibe la velocidad la posicion y el nombre del txt y se lo pasa como argumentos
	// a la clase procesosNeos
	public void lanzarProcesos(Double vel, Double pos, String nom) {
		String clase = "AEV2.procesosNeos";
		try {

			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classpath = System.getProperty("java.class.path");
//			    System.out.println(classpath);
			String className = clase;

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classpath);
			command.add(className);
			command.add(Double.toString(vel));
			command.add(Double.toString(pos));
			command.add(nom);

//			    System.out.println("Comando que se pasa a ProcessBuilder: " + command);
//				System.out.println("Comando a ejecutar en cmd.exe: " + command.toString().replace(",",""));

			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.inheritIO().start();
//			    Process process = builder.start();
			if(cores == maxCores) {
				process.waitFor();
			}else {
				maxCores++;
			}
			
//			System.out.println(process.exitValue());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		//Variables en la que almacenaremos datos
		String nombre = "";
		double posicionNEO = 0;
		double velocidadNEO = 0;

		//inicio del contador de tiempo
		long inicio = System.currentTimeMillis();
		
		//Genero el reader del archivo indicado
		String path = "NEOs.txt";
		File myObj = new File(path);
		Scanner myReader;

		int i = 1;
		try {
			myReader = new Scanner(myObj);
			//Ejecuto el lanzador mientras hayan lineas en el archivo y mientras no se ejecuten m�s veces que cores hay disponibles
			while (myReader.hasNextLine() && cores >= i) {
				String line = myReader.nextLine();
				String[] arr = line.split(",");
				nombre = arr[0];
				posicionNEO = Double.parseDouble(arr[1]);
				velocidadNEO = Double.parseDouble(arr[2]);
				
				Lanzador l = new Lanzador();
				l.lanzarProcesos(velocidadNEO, posicionNEO, nombre);
				i++;

			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Duermo durante 0.1 secs el codigo para que me salga ordenado en la consola
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//fin del contador de tiempo e imprimo en la consola el tiempo de ejecuci�n
		long fin = System.currentTimeMillis();
		double tiempo = (double) ((fin - inicio) / 1000);
		System.out.println();
		System.out.println("-------------------------------------------");
		System.out.println("Duracion ejecucion " + tiempo + " segundos");
		double tMedio = (double) (tiempo / cores);
		System.out.println("Tiempo medio " + tMedio + " segundos");
	}

}
