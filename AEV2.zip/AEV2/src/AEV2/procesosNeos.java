package AEV2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Scanner;

public class procesosNeos {



	//funcion en la que genero los txt con cada NEO ademas de calcular las probabilidades de impacto
	//le paso por parametro la velocidad la posicion y el nombre del neo a calcular
	public String procesosNEO(double vel, double pos, String nom) {

		// Calcula la probabilidad de colision con el NEO
		double posicionTierra = 1;
		double velocidadTierra = 100;
		for (int i = 0; i < (50 * 365 * 24 * 60 * 60); i++) {
			pos = pos + vel * i;
			posicionTierra = posicionTierra + velocidadTierra * i;
		}
		double resultado = 100 * Math.random() * Math.pow(((pos - posicionTierra) / (pos + posicionTierra)), 2);
		File f = new File(nom + ".txt");
		FileWriter myWriter;
		//Redondeo resultado
		BigDecimal bd = new BigDecimal(resultado);
		bd = bd.setScale(2, RoundingMode.UP);
		//Escribo dentro del txt
		try {
			myWriter = new FileWriter(nom + ".txt");
			myWriter.write("La probabilidad de colision es de un " + bd.toString() + "%");
			myWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		return bd.toString();

	}

	public static void main(String[] args) {

		//guardo las variables que le paso desde lanzador
		double velocidadNEO = Double.parseDouble(args[0]);
		double posicionNEO = Double.parseDouble(args[1]);
		String nombre = args[2];
		
		//llamo a la funcion procesosNeos
		procesosNeos p = new procesosNeos();
		String prob = p.procesosNEO(velocidadNEO, posicionNEO, nombre);
		System.out.println(nombre);
		double str1 = Double.parseDouble(prob);
		//Imprimo por pantalla las probabilidades de impacto
		if ( str1 >= 10.00) {
			System.err.println("La probabilidad de choque es de un " + prob + "% PELIGRO");
		} else {
			System.out.println("La probababiidad de choque es de un " + prob 
					+ "% no hay problema");
		}

	}
	

}
