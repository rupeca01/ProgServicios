package EjerciciosT1;

public class ej1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1 = 2;
		int n2 = 3;
		
		int total = n1 + n2;
		
		System.out.println(n1 + " + " + n2 + " = " + total);
	}

}
